//
//  ViewController.swift
//  gitApp
//
//  Created by Bekzat on 24.11.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //code 1
        /*
         code
         code
         code...
         */
        

        //code 2 New
        /*

         code2new
         code2new
         code2new

         */
        
        // APP STORE 1
        
        //Code 3
        /*

         code 3...

         */
        
        //Code 4
        /*

         code 4...

         */
        
        //fix bugs
        
        // APP STORE 2 
    }


}

